<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDesignationTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('_designation', function (Blueprint $table) {
            $table->id();
			$table->string('name');
            $table->timestamps();
        });
		      // Insert data
    DB::table('designations')->insert([
        ['name' => 'Manager', 'created_at' => now()],
        ['name' => 'Developer', 'created_at' => now()],
    ]);
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('_designation');
    }
}
