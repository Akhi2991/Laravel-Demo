<!DOCTYPE html>
<html>
<head>
    <title>Dynamic User Listing</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
	<style>
	td{
	text-align:center;
	}
	</style>
</head>
<body>
    <h1>User Listing</h1>

    <!-- Search Bar -->
    <input type="text" id="search" placeholder="Search by Name, Department, or Designation">
    
    <!-- User Table -->
    <table border="1" id="user-table">
        <thead>
            <tr>
                <th>Name</th>
                <th>Department</th>
                <th>Designation</th>
                <th>Phone Number</th>
            </tr>
        </thead>
        <tbody>
            <!-- Dynamic content will be appended here -->
        </tbody>
    </table>

    <script>
        $(document).ready(function () {
            // Fetch initial data
            fetchUsers();

            // Fetch data on keyup
            $('#search').on('keyup', function () {
                let search = $(this).val();
                fetchUsers(search);
            });

            function fetchUsers(search = '') {
                $.ajax({
                    url: "{{ route('users.fetch') }}",
                    method: "GET",
                    data: { search: search },
                    success: function (data) {
                        let rows = '';
                        if (data.length > 0) {
                            $.each(data, function (key, user) {
                                rows += `
                                    <tr>
                                        <td>${user.name}</td>
                                        <td>${user.department?.name || 'N/A'}</td>
                                        <td>${user.designation?.name || 'N/A'}</td>
                                        <td>${user.phone_no}</td>
                                    </tr>
                                `;
                            });
                        } else {
                            rows = `<tr><td colspan="4">No users found</td></tr>`;
                        }
                        $('#user-table tbody').html(rows);
                    },
                    error: function (xhr, status, error) {
                        console.error("Error fetching users:", error);
                    }
                });
            }
        });
    </script>
</body>
</html>
