<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\models\Users;

class UsersController extends Controller
{
	 public function index()
    {
        return view('users.index', ['search' => '', 'users' => []]);
    }
	public function fetchUsers(Request $request)
    {
        $search = $request->get('search');

        $users = Users::with('department', 'designation')
            ->where('name', 'like', "%$search%")
            ->orWhereHas('department', function ($query) use ($search) {
                $query->where('name', 'like', "%$search%");
            })
            ->orWhereHas('designation', function ($query) use ($search) {
                $query->where('name', 'like', "%$search%");
            })
            ->get();

        return response()->json($users);
    }
}
